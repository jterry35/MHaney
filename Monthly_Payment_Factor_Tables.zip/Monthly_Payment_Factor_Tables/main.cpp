#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include <cstdlib>

using namespace std;

/*  Mike Haney 01222019
    Monthly Payment Factor Table  */

//prototype to prompt user to enter initial interest rate
double initialInterestRate();
//prototype to prompt user to enter terminal interest rate
double terminalInterestRate();
//prototype to prompt user to enter interest rate incrementation
double incValueInterestRate();
//prototype to prompt user to enter years
double yearsInterestRate();
//prototype to hold calculations
double factorFormArithmetic(double, double); //pass as parameter = initial, years
//prototype to display result
void displayResult(double, double, double, double, double); //pass in all data

//create an output file to hold program result
ofstream outfile;

int main()
{
    //to hold initial interest rate
    double initialIR = 0.0;
    //to hold terminal interest rate
    double terminalIR = 0.0;
    //to hold the incremental interest rate value
    double incrementIR = 0.0;
    //to hold the total years
    double years = 0.0;
    //to hold the Factor Form arithmetic
    double factorForm = 0.0;

    //for text formatting
    cout << fixed << showpoint << setprecision(5);
    //to call and return interest rate
    initialIR = initialInterestRate();
    cout << "Initial IR = " << initialIR << endl;
    //to call and return terminal interest rate
    terminalIR = terminalInterestRate();
    cout << "Terminal IR = " << terminalIR << endl;
    //to call and return the IR increment value
    incrementIR = incValueInterestRate();
    cout << "Increment value = " << incrementIR << endl;
    //to call and return years
    years = yearsInterestRate();
    cout << "Years entered = " << years << endl;
    //to call and return Factor Form Arithmetic
    factorForm = factorFormArithmetic(initialIR, years);
    cout << "Factor Form = " << factorForm << endl;

    //to display result
    displayResult(initialIR, terminalIR, incrementIR, years, factorForm);




    return 0;
}
//function to elicit the initial rate from user
double initialInterestRate()
{
    //to hold the rate entered by user
    double rate = 0.0;

    //to get rate
    cout << "Please enter interest rate: ";
    cin >> rate;

    //to return rate back to main
    return rate;
}
//function to elicit terminal interest rate
double terminalInterestRate()
{
    //to hold terminal rate
    double terminal = 0.0;

    //to get terminal rate
    cout << "Please enter terminal rate: ";
    cin >> terminal;

    //to return terminal rate back to main
    return terminal;
}
//function to elicit increment value
double incValueInterestRate()
{
    //to hold increment value
    double increment = 0.0;

    //to get value
    cout << "Please enter the increment value: ";
    cin >> increment;

    //to return increment value back to main
    return increment;
}
//function to elicit years from user
double yearsInterestRate()
{
    //to hold years
    double years = 0.0;

    //to get years
    cout << "Please enter years: ";
    cin >> years;

    //to return years back to main
    return years;
}
//function to calculate factor form arithmetic
double factorFormArithmetic(double initial, double years)
{
    //to hold Factor Form Arithmetic value
    double factorForm = 0.0;
    //to hold I = 0.08333
    double I = 0.0;
    //to hold months
    double months = 0.0;

    I = (1/12.0) * initial;
    months = years * 12.0;
    factorForm = (pow(I+1, months) * I) / (pow(I+1, months) - 1);

    //to return Factor form to main
    return factorForm;
}
void displayResult(double initial, double terminal, double inc, double years, double factorForm)
{
    /* three loops. first will be a while.
    this will ensure seven columns only are printed per iteration
    second will be a count-controlled loop to traverse years.
    third will be a count-controlled loop to traverse columns/Int Rate */

    //place factorForm in loop with inc in order to increment through each iteration

    //to hold Factor Form Arithmetic value
    double newFactorForm = 0.0;
    //to hold I
    double I = 0.0;
    //to hold months
    double months = 0.0;

    I = I + (1/12.0) * (initial + inc);
    months = years * 12.0;
    newFactorForm = (pow(I+1, months) * I) / (pow(I+1, months) - 1);

    //to prime the read
    //cout << "IR: " << factorForm;
    cout << endl;
    //our factor form is our X in RCs
    cout << "      \t" << factorForm << "   ";
    for (int z =2; z <= terminal; z++)
    {
        I = I + (1/12.0) * (initial + inc);
        months = years * 12.0;
        newFactorForm = (pow(I+1, months) * I) / (pow(I+1, months) - 1);
        cout << newFactorForm << "    ";
    }

cout << endl << "---------------------------------------------------------------------------------------------" << endl;

    for (int x = 1; x <= years; x++)
    {
        cout << "Year# " << x;
        for (int y = 0; y < terminal; y++)//y + inc)
        {

            cout << "     X     " ;
           // cout << "Year: " << years << endl;
        }
        cout << endl;
    }
}
